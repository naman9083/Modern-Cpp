#include<bits/stdc++.h>

enum class Rank
{
    FIRST,
    SECOND,
    THIRD
};
enum class Gear
{

    FIRST,
    SECOND,
    THIRD
};
enum class Position
{

    FIRST,
    SECOND,
    THIRD
};
int main(int argc, char const *argv[])
{
    //we cannnot force the user to use enum name as a prefix
    enum Rank r1 = Rank::FIRST;
    enum Gear g1 = Gear::FIRST;
    
    
        
    return 0;
}