#ifndef CARTYPE_HPP
#define CARTYPE_HPP

/*
    data : real-value
    categorical: moths in a year

*/
enum class CarType
{
    SEDAN,
    SUV,
    HATCHBATCH
};

#endif