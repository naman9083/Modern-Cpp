#ifndef PERMITTYPE_HPP
#define PERMITTYPE_HPP

enum class PermitType
{
    LEASE,
    OWNED,
};

#endif // PERMITTYPE_HPP
