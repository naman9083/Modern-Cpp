#ifndef TOURISTVEHICLETYPE_HPP
#define TOURISTVEHICLETYPE_HPP

enum class TouristVehicleType
{
    BUS,
    CAB,
    BIKE,
    DEFAULT
};

#endif // TOURISTVEHICLETYPE_HPP


