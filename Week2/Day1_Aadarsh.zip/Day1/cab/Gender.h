#ifndef GENDER_H
#define GENDER_H

enum class Gender{
    MALE,
    FEMALE,
    OTHER
};

#endif // GENDER_H
