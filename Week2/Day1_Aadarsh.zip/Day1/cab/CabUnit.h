#ifndef CABUNIT_H
#define CABUNIT_H

class CabUnit
{
private:
    /* data */
public:
    CabUnit(/* args */) {}
    ~CabUnit() {}
};

#endif // CABUNIT_H
