#ifndef DRIVER_H
#define DRIVER_H

class Driver
{
private:
    /* data */
public:
    Driver(/* args */) {}
    ~Driver() {}
};

#endif // DRIVER_H
